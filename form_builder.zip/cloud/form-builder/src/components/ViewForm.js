import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './ViewForm.css';

const ViewForm = () => {
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [responses, setResponses] = useState({});
  const navigate = useNavigate(); // Initialize navigate

  useEffect(() => {
    const fetchForm = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/forms/${id}`);
        setForm(res.data);
      } catch (error) {
        console.error('Error fetching form:', error);
      }
    };
    fetchForm();
  }, [id]);

  const handleInputChange = (e, index) => {
    setResponses({ ...responses, [index]: e.target.value });
  };

  const goBack = () => {
    navigate('/'); // Navigate to home
  };

  if (!form) return <div>Loading...</div>;

  return (
    <div className="view-form-container">
      <h1>{form.title}</h1>
      <form>
        {form.fields.map((field, index) => (
          <div key={index} className="form-field">
            <label>{field.title}</label>
            <input
              type={field.inputType}
              placeholder={field.placeholder}
              value={responses[index] || ''}
              onChange={(e) => handleInputChange(e, index)}
            />
          </div>
        ))}
        <button type="button" onClick={goBack} className="back-button">
          Back to Home
        </button>
      </form>
    </div>
  );
};

export default ViewForm;
