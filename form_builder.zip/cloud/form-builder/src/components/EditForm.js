import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import './EditForm.css'; // Make sure to add CSS for styling

const EditForm = () => {
  const { id } = useParams();
  const [title, setTitle] = useState('');
  const [fields, setFields] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchForm = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/forms/${id}`);
        setTitle(res.data.title);
        setFields(res.data.fields);
      } catch (error) {
        console.error('Error fetching form:', error);
      }
    };
    fetchForm();
  }, [id]);

  const addField = (type) => {
    if (fields.length < 20) {
      setFields([
        ...fields,
        { type, title: '', placeholder: '', inputType: type },
      ]);
    } else {
      alert('Maximum of 20 fields allowed.');
    }
  };

  const onDragStart = (index) => (event) => {
    event.dataTransfer.setData('fieldIndex', index);
  };

  const onDrop = (event) => {
    const draggedFieldIndex = event.dataTransfer.getData('fieldIndex');
    const dropIndex = event.currentTarget.dataset.index;

    const newFields = [...fields];
    const [draggedField] = newFields.splice(draggedFieldIndex, 1);
    newFields.splice(dropIndex, 0, draggedField);

    setFields(newFields);
  };

  const onDragOver = (event) => {
    event.preventDefault();
  };

  const handleFieldChange = (index, key, value) => {
    const newFields = [...fields];
    newFields[index][key] = value;
    setFields(newFields);
  };

  const removeField = (index) => {
    // const confirmDelete = window.confirm(
    //   'Are you sure you want to delete this field?'
    // );
    // if (confirmDelete) {
    setFields(fields.filter((_, i) => i !== index));
    //}
  };

  const saveForm = async () => {
    try {
      await axios.put(`http://localhost:5000/api/forms/${id}`, {
        title,
        fields,
      });
      navigate('/');
    } catch (error) {
      console.error('Error saving form:', error);
    }
  };

  const goBack = () => {
    navigate('/');
  };

  return (
    <div className="edit-form-container">
      <h1>Edit Form</h1>
      <input
        type="text"
        placeholder="Form Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="form-title-input"
      />
      <div className="add-field-container">
        <button onClick={() => addField('text')} className="add-field-button">
          Add Text Field
        </button>
        <button onClick={() => addField('email')} className="add-field-button">
          Add Email Field
        </button>
        <button
          onClick={() => addField('password')}
          className="add-field-button"
        >
          Add Password Field
        </button>
        <button onClick={() => addField('number')} className="add-field-button">
          Add Number Field
        </button>
        <button onClick={() => addField('date')} className="add-field-button">
          Add Date Field
        </button>
      </div>

      <h2>Preview</h2>
      <div className="fields-preview">
        {fields.map((field, index) => (
          <div
            key={index}
            draggable
            onDragStart={onDragStart(index)}
            onDrop={onDrop}
            onDragOver={onDragOver}
            data-index={index}
            className="field-preview"
          >
            <input
              type="text"
              value={field.title}
              onChange={(e) =>
                handleFieldChange(index, 'title', e.target.value)
              }
              className="field-title-input"
              placeholder="Field Title"
            />
            <input
              type="text"
              value={field.placeholder}
              onChange={(e) =>
                handleFieldChange(index, 'placeholder', e.target.value)
              }
              className="field-placeholder-input"
              placeholder="Placeholder"
            />
            {/* <input
              type={field.inputType}
              placeholder={field.placeholder}
              readOnly
              className="field-preview-input"
            /> */}
            <button
              onClick={() => removeField(index)}
              //className="remove-field-button"
            >
              Delete
            </button>
          </div>
        ))}
      </div>

      <div className="form-actions">
        <button onClick={saveForm} className="save-form-button">
          Save Form
        </button>
        <button onClick={goBack} className="back-button">
          Back to Home
        </button>
      </div>
    </div>
  );
};

export default EditForm;
