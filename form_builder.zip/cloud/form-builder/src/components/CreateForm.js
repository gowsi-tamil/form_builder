import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './CreateForm.css'; // Import the CSS file for styling

const CreateForm = () => {
  const [title, setTitle] = useState('');
  const [fields, setFields] = useState([]);
  const [newField, setNewField] = useState({
    title: '',
    placeholder: '',
    inputType: 'text', // default type
  });
  const navigate = useNavigate();

  const handleFieldChange = (e) => {
    const { name, value } = e.target;
    setNewField((prev) => ({ ...prev, [name]: value }));
  };

  const addField = () => {
    if (newField.title && newField.placeholder && fields.length < 20) {
      setFields([
        ...fields,
        {
          type: newField.inputType,
          title: newField.title,
          placeholder: newField.placeholder,
          inputType: newField.inputType,
        },
      ]);
      setNewField({
        title: '',
        placeholder: '',
        inputType: 'text',
      });
    } else {
      alert(
        'Please fill all fields and ensure there are fewer than 20 fields.'
      );
    }
  };

  const onDragStart = (index) => (event) => {
    event.dataTransfer.setData('fieldIndex', index);
  };

  const onDrop = (event) => {
    const draggedFieldIndex = event.dataTransfer.getData('fieldIndex');
    const dropIndex = event.currentTarget.dataset.index;

    const newFields = [...fields];
    const [draggedField] = newFields.splice(draggedFieldIndex, 1);
    newFields.splice(dropIndex, 0, draggedField);

    setFields(newFields);
  };

  const onDragOver = (event) => {
    event.preventDefault();
  };

  const removeField = (index) => {
    setFields(fields.filter((_, i) => i !== index));
  };

  const saveForm = async () => {
    if (title && fields.length > 0) {
      try {
        await axios.post('http://localhost:5000/api/forms', { title, fields });
        navigate('/');
      } catch (error) {
        console.error('Error saving form:', error);
        alert('Error saving form. Please try again.');
      }
    } else {
      alert('Please enter a form title and add at least one field.');
    }
  };

  return (
    <div className="create-form-container">
      <h1>Create Form</h1>
      <input
        type="text"
        placeholder="Form Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="form-title-input"
      />

      <div className="add-field-container">
        <input
          type="text"
          name="title"
          placeholder="Field Title"
          value={newField.title}
          onChange={handleFieldChange}
          className="field-input"
        />
        <input
          type="text"
          name="placeholder"
          placeholder="Placeholder"
          value={newField.placeholder}
          onChange={handleFieldChange}
          className="field-input"
        />
        <select
          name="inputType"
          value={newField.inputType}
          onChange={handleFieldChange}
          className="field-select"
        >
          <option value="text">Text</option>
          <option value="email">Email</option>
          <option value="password">Password</option>
          <option value="number">Number</option>
          <option value="date">Date</option>
        </select>
        <button onClick={addField} className="add-field-button">
          Add Field
        </button>
      </div>

      <h2>Preview</h2>
      <div className="fields-preview">
        {fields.map((field, index) => (
          <div
            key={index}
            draggable
            onDragStart={onDragStart(index)}
            onDrop={onDrop}
            onDragOver={onDragOver}
            data-index={index}
            className="field-preview"
          >
            <div className="field-info">
              <input
                type={field.title}
                placeholder={field.title}
                readOnly
                className="field-preview-input"
              />
              <input
                type={field.inputType}
                placeholder={field.placeholder}
                readOnly
                className="field-preview-input"
              />
            </div>
            {/* <button
              onClick={() => removeField(index)}
              className="remove-field-button"
            >
              Remove
            </button> */}

            <button
              onClick={() => removeField(index)}
              //className="field-preview-input"
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <button onClick={saveForm} className="save-form-button">
        Save Form
      </button>
    </div>
  );
};

export default CreateForm;
