import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './Home.css';

const Home = () => {
  const [forms, setForms] = useState([]);

  useEffect(() => {
    const fetchForms = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/forms');
        setForms(res.data);
      } catch (error) {
        console.error('Error fetching forms:', error);
      }
    };
    fetchForms();
  }, []);

  const deleteForm = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/forms/${id}`);
      setForms(forms.filter((form) => form._id !== id));
    } catch (error) {
      console.error('Error deleting form:', error);
    }
  };

  return (
    <div className="home-container">
      <h1 className="home-title">My Forms</h1>
      <Link to="/form/create" className="create-form-button">
        + Create New Form
      </Link>
      <ul className="form-list">
        {forms.map((form) => (
          <li key={form._id} className="form-item">
            <Link to={`/form/${form._id}`} className="form-link">
              {form.title}
            </Link>
            <div className="form-actions">
              <Link to={`/form/${form._id}/edit`} className="edit-button">
                Edit
              </Link>
              <button
                onClick={() => deleteForm(form._id)}
                className="delete-button"
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;
